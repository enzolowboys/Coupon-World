<?php

class Application_Resource_coupon_Item extends Zend_Db_Table_Row_Abstract
{   
	public function init()
    {
    }
    
}