<?php

class Application_Resource_Relazione extends Zend_Db_Table_Abstract
{
    protected $_name    = 'relazione';
    protected $_primary  = 'idrelazione';
    protected $_rowClass = 'Application_Resource_Relazione_Item';
    
	public function init()
    {
    }
    
    /*controlla se ci sono*/
    
    
    
}