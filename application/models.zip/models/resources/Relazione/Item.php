<?php

class Application_Resource_Relazione_Item extends Zend_Db_Table_Row_Abstract
{   
	public function init()
    {
    }
    
}